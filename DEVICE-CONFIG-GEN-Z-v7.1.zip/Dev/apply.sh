dev=@HenVx0
ver=7.1
echo ""
echo "
█▀▄ █▀▀ █░█ █ █▀▀ █▀▀   █▀▀ █▀▀ █▄░█   ▀█
█▄▀ ██▄ ▀▄▀ █ █▄▄ ██▄   █▄█ ██▄ █░▀█   █▄"
echo "[ 𝗜𝗻𝗳𝗼𝗿𝗺𝗮𝘁𝗶𝗼𝗻 𝗔𝗯𝗼𝘂𝘁 ] "
echo "Developer : ${dev} "
echo "Version : ${ver} "
sleep 2
echo ""
echo ""
sleep 5
echo " [■□□□□□□□□□]  "
sleep 2
echo " [■■□□□□□□□□]  "
sleep 1
echo " [■■■□□□□□□□]  "
sleep 2
echo " [■■■■□□□□□□]  "
sleep 1
echo " [■■■■■□□□□□]  "
sleep 2
echo " [■■■■■■□□□□]  "
sleep 1
echo " [■■■■■■■□□□]  "
sleep 2
echo " [■■■■■■■■□□]  "
sleep 1
echo " [■■■■■■■■■□] "
sleep 0.5
echo ""
echo " Succes Apply Device Config [ 45 Type ]"
echo ""

#AmdroidConfig
set_android() {
cmd device_config put dalvik dedupe_strings true
cmd device_config put dalvik dex2oat_max_inference_threads 4
cmd device_config put dalvik dex2oat_thread_count 4
cmd device_config put dalvik jit_enable 1
cmd device_config put dalvik jit_max_threads 4
cmd device_config put dalvik jit_mode 2
cmd device_config put dalvik max_threads 8
cmd device_config put dalvik vm_heapsize 512m
cmd device_config put package_native_code optimizable_apps true
cmd device_config put graphics max_caches 3
cmd device_config put graphics max_texture_atlas_size 128
cmd device_config put graphics max_layers 11
cmd device_config put graphics max_texture_size 128
cmd device_config put graphics max_cpu_usage 3.0
cmd device_config put graphics_sf swapinterval 0
cmd device_config put input filtered_accel_event_rate_hz 200
cmd device_config put input accel_buffer_depth 2048
cmd device_config put input accel_buffer_timeout_ms 50
cmd device_config put input filtered_accel_lpf_coef 0.1
cmd device_config put activity_manager min_low_ram_task_aspect_ratio 0.1
cmd device_config put grapichs refresh_rate 90
cmd device_config put input tap_duration 60
cmd device_config put input gesture_min_time 100
cmd device_config put activity_manager min_frame_duration_ms 8
cmd device_config put activity_manager max_phantom_processes 0
cmd device_config put activity_manager max_cached_processes 256
cmd device_config put activity_manager set_sync_disabled_for_tests persistent
cmd device_config put activity_manager max_empty_time_millis 43200000
cmd device_config put activity_manager window_focus_timeout 500
cmd device_config put activity_manager render_thread_priority FORCECOPY
cmd device_config put activity_manager foreground_service_max_memory_kb 500
cmd device_config put activity_manager background_service_max_memory_kb 250
cmd device_config put activity_manager free_memory_percent_for_background_processes 10
cmd device_config put activity_manager free_memory_percent_for_foreground_processes 20
cmd device_config put activity_manager foreground_service_keep_alive_time_ms 10000
cmd device_config put activity_manager background_service_keep_alive_time_ms 5000
cmd device_config put input default_key_press_repeat_rate 15
cmd device_config put input gesture_min_distance 10
cmd device_config put input touch_screen_sample_interval_ms 5
cmd device_config put thermal high_temp_limit 95
cmd device_config put thermal low_temp_limit 50
cmd device_config put cpu cpu_max_pwr_mgmnt=2.0
cmd device_config put cpu max_cpu_power=3.0
cmd device_config put gpu gpu_max_pwr_mgmnt=3.0
cmd device_config put gpu max_gpu_power=3.0
cmd device_config put surfaceflinger surfaceflinger.vsync.enable true
cmd device_config put surfaceflinger surfaceflinger.vsync.timeout 10
cmd device_config put window_manager hardware_accelerated true
cmd device_config put cpu scalling_governor=performance
cmd device_config put vendor_system_native background_cpuset=1
cmd device_config put systemui performance_mode_system=true
cmd device_config put grapichs texture_lacenty_high 0
cmd device_config put surfaceflinger surfaceflinger.vsync.interpolation false
cmd device_config put surfaceflinger surfaceflinger.layers.max 100
cmd device_config put surfaceflinger surfaceflinger.layers.default 10
cmd device_config put systemui window_cornerRadius 0
cmd device_config put systemui window_blur 0
cmd device_config put systemui window_shadow 0
cmd device_config put input filtered_accel_event_rate_hz 400
}
set_android > /dev/null 2>&1 

#Low Reso
set_low() {
device_config put game_overlay com.miHoYo.GenshinImpact mode=2,downscaleFactor=0.4:mode=2,downscaleFactor=0.7,device_config put game_overlay com.tencent.ig mode=2,downscaleFactor=0.4:mode=2,downscaleFactor=0.7,device_config put game_overlay com.garena.game.codm mode=2,downscaleFactor=0.4:mode=2,downscaleFactor=0.7,device_config put game_overlay com.mobilelegends.hwag mode=2,downscaleFactor=0.4:mode=2,downscaleFactor=0.7,device_config put game_overlay com.ea.gp.fifamobile mode=2,downscaleFactor=0.4:mode=2,downscaleFactor=0.7
device_config put game_overlay com.HoYoverse.hkrpgoversea mode=2,downscaleFactor=0.4:mode=2,downscaleFactor=0.7
device_config put game_overlay com.mobile.legends mode=2,downscaleFactor=0.4:mode=2,downscaleFactor=0.7
device_config put game_overlay com.dts.freefiremax mode=2,downscaleFactor=0.4:mode=2,downscaleFactor=0.7
device_config put game_overlay com.dts.freefireth mode=2,downscaleFactor=0.4:mode=2,downscaleFactor=0.7
device_config put game_overlay com.netease.newspike mode=2,downscaleFactor=0.4:mode=2,downscaleFactor=0.7
device_config put game_overlay com.mojang.minecraftpe mode=2,downscaleFactor=0.4:mode=2,downscaleFactor=0.7
}
set_low > /dev/null 2>&1