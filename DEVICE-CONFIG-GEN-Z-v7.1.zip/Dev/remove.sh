sleep 0.5
echo " Wait Remove Device Config  ! ! "
echo ""
sleep 5
echo " [■□□□□□□□□□]  "
sleep 2
echo " [■■□□□□□□□□]  "
sleep 2
echo " [■■■□□□□□□□]  "
sleep 2
echo " [■■■■□□□□□□]  "
sleep 2
echo " [■■■■■□□□□□]  "
sleep 2
echo " [■■■■■■□□□□]  "
sleep 2
echo " [■■■■■■■□□□]  "
sleep 2
echo " [■■■■■■■■□□]  "
sleep 2
echo " [■■■■■■■■■□] "
sleep 0.5
echo ""
echo " Succes Removed Device Config [ 39 Type ]"
echo ""


#AmdroidConfigRemove
remove_android() {
cmd device_config delete dalvik dedupe_strings 
cmd device_config delete dalvik dex2oat_max_inference_threads 
cmd device_config delete dalvik dex2oat_thread_count 
cmd device_config delete dalvik jit_enable 
cmd device_config delete dalvik jit_max_threads 
cmd device_config delete dalvik jit_mode 
cmd device_config delete dalvik max_threads
cmd device_config delete dalvik vm_heapsize 
cmd device_config delete package_native_code optimizable_apps 
cmd device_config delete graphics max_caches 
cmd device_config delete graphics max_texture_atlas_size
cmd device_config delete graphics max_layers 
cmd device_config delete graphics max_texture_size 
cmd device_config delete graphics max_cpu_usage 
cmd device_config delete graphics_sf swapinterval 
cmd device_config delete input filtered_accel_event_rate_hz 
cmd device_config delete input accel_buffer_depth 
cmd device_config delete input accel_buffer_timeout_ms 
cmd device_config delete input filtered_accel_lpf_coef 
cmd device_config delete activity_manager min_low_ram_task_aspect_ratio 
cmd device_config delete grapichs refresh_rate
cmd device_config delete input tap_duration 
cmd device_config delete input gesture_min_time 
cmd device_config delete input default_key_press_repeat_rate 
cmd device_config delete input gesture_min_distance 
cmd device_config delete input touch_screen_sample_interval_ms 
cmd device_config delete thermal high_temp_limit 
cmd device_config delete thermal low_temp_limit 
cmd device_config delete window_manager hardware_accelerated 
cmd device_config delete cpu scalling_governor
cmd device_config delete vendor_system_native background_cpuset
cmd device_config delete systemui performance_mode_system
cmd device_config delete systemui window_cornerRadius
cmd device_config delete systemui window_blur
cmd device_config delete systemui window_shadow
cmd device_config delete input filtered_accel_event_rate_hz
} 
remove_android > /dev/null 2>&1 